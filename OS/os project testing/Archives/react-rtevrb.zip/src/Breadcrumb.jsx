import React from 'react';

function Breadcrumb() {
  return (
    <div className="row smallwords">
      <div className="col-3 Nokiaheader" style={{ marginLeft: '50px' }}>
        Home | Insights and Innovation | Discover 2030
      </div>
    </div>
  );
}

export default Breadcrumb;
