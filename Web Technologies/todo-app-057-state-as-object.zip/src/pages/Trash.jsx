import PurgedTasks from "../components/PurgedTasks";

function Trash() {
  return <PurgedTasks HeadingContainer="h2" />;
}

export default Trash;
