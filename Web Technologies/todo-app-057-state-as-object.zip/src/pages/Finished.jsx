import CompletedTasks from "../components/CompletedTasks";

function Finished() {
  return <CompletedTasks HeadingContainer="h2" />;
}

export default Finished;
