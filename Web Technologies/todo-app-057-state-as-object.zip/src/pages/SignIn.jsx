import LogIn from "../components/LogIn";

function SignIn() {
  return <LogIn></LogIn>;
}

export default SignIn;
