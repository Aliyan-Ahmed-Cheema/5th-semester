function Home() {
  return <h2>Admin Home</h2>;
}

export default Home;
