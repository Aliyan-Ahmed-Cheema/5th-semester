import "./PendingTasks.css";
import TaskPending from "./TaskPending";

function PendingTasks({ tasks, onDone, onDelete, MessageComponent }) {
  // let MessageComponent = "span";
  // let MessageComponent = ShowMessage;

  // const tasks = props.tasks;
  // const onDone = props.onDone;
  // const onDelete = props.onDelete;

  const list = tasks.map((task, ind) => {
    return (
      <TaskPending
        key={ind}
        id={task.id}
        title={task.title}
        createDate={task.createDate}
        onDone={onDone}
        onDelete={onDelete}
      />
    );
  });

  return (
    <div className="pendingTask_container">
      <MessageComponent>Pending Tasks</MessageComponent>

      {list}
    </div>
  );
}

export default PendingTasks;
