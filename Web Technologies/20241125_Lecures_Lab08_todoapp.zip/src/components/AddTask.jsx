import ShowMessage from "./ShowMessage";

import "./AddTask.css";
import { useRef, useState } from "react";

// Functional Component
function AddTask(props) {
  let [taskTitle, setTaskTitle] = useState("");

  const titleRef = useRef();

  let [add, setAdd] = useState(false);

  // setTaskTitle(titleRef.current.value); // ERROR

  function handleInputChange(event) {
    setAdd(false);
    setTaskTitle(titleRef.current.value);
  }

  function handleAdd() {
    props.onAdd(taskTitle);
    setAdd(true);
    // setTaskTitle("");
  }

  let message = "";

  if (add) {
    // Message  added
    message = (
      <ShowMessage>
        <i>Task Added Successfully!</i>
      </ShowMessage>
    );
  } else {
    // Message not added yet
    message = (
      <ShowMessage>
        {/* <i>Please add new task ...</i> */}

        {taskTitle ? (
          <div>
            <span className="taskItem">
              {new Date().toLocaleDateString("de-DE")}
            </span>
            <span className="taskItem">{taskTitle}</span>
          </div>
        ) : (
          <small>Please add new task ...</small>
        )}
      </ShowMessage>
    );
  }

  return (
    <div className="addTask_container">
      <h1>Add Task</h1>
      <label>Add new task: </label>
      <input ref={titleRef} type="text" onChange={handleInputChange} />
      <button onClick={handleAdd}>Add</button>
      {message}

      {/* <ShowMessage>Task Added Successfully!</ShowMessage> */}
      {/* <ShowMessage>
        <i>Task Added Successfully!</i>
      </ShowMessage> */}
    </div>
  );
}

export default AddTask;
