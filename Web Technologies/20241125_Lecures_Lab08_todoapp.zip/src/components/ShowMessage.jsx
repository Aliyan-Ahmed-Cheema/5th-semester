// Functional Component
function ShowMessage(props) {
  return <div>{props.children}</div>;
}

export default ShowMessage;
