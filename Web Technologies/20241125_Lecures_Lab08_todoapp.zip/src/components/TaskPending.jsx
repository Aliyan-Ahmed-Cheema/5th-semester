import { useState } from "react";

// Functional Component
function TaskPending(props) {
  return (
    <div>
      <span className="taskItem">{props.createDate}</span>
      <span className="taskItem">{props.title}</span>
      <button onClick={() => props.onDone(props.id)}>done</button>
      <button onClick={() => props.onDelete(props.id)}>delete</button>
    </div>
  );
}

export default TaskPending;
