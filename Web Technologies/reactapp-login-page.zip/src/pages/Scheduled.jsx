import PendingTasks from "../components/PendingTasks";

function Scheduled() {
  return <PendingTasks headingContainer="h2" />;
}

export default Scheduled;
