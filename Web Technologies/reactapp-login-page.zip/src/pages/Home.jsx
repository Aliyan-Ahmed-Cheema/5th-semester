import AddTask from "../components/AddTask";
import ManageTasks from "../components/ManageTasks";

function Home() {
  return (
    <>
      <AddTask />
      <ManageTasks />
    </>
  );
}

export default Home;
