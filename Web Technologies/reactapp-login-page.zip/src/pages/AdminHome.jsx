function AdminHome() {
  return <h2>Admin Home</h2>;
}

export default AdminHome;
