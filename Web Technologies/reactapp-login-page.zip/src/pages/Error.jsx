function Error() {
  return <h1 className="App">An Error Occured </h1>;
}

export default Error;
