function RootError() {
  return <h1 className="App">A RootError Occured </h1>;
}

export default RootError;
