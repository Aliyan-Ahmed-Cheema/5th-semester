import AddTask from "../components/AddTask";

function AdminNew() {
  return <AddTask />;
}
export default AdminNew;
