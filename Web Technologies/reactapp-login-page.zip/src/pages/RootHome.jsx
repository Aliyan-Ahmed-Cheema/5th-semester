import LogIn from "../components/LogIn";

function RootHome() {
  return <LogIn></LogIn>;
}

export default RootHome;
