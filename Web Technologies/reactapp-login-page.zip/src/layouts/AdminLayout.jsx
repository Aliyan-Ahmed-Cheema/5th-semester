// Layout (or say, wrapper) for child routes
import { Outlet } from "react-router-dom";
// import Header from "./Header";

function AdminLayout() {
  return (
    <div style={{ background: "lightgray" }}>
      <h1>Admin Panel</h1>
      <Outlet></Outlet>
    </div>
  );
}

export default AdminLayout;
