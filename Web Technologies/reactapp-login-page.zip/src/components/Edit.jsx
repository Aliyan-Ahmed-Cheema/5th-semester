// Functional Component
function Edit({ id }) {
  return <h1>Edit Task {id}</h1>;
}

export default Edit;
