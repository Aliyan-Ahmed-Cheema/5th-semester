//Note that the original website with the same link has changed between Assignment 1 and Assignment 2
//This code follows the pattern of the page made in assignment 1
import React from 'react';

function Breadcrumb() {
  return (
    <div className="row smallwords">
      <div className="col-3 Nokiaheader" style={{ marginLeft: '50px' }}>
        Home | Insights and Innovation | Discover 2030
      </div>
    </div>
  );
}

export default Breadcrumb;
