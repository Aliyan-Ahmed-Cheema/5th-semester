export const INITIAL_TASKS = [
  {
    id: 101,
    title: "Going to admission office",
    createDate: "20.10.2023",
    done: false,
    trash: false,
  },
  {
    id: 102,
    title: "Visit library",
    createDate: "16.10.2023",
    done: false,
    trash: false,
  },
  {
    id: 103,
    title: "Attending seminar",
    createDate: "19.10.2023",
    done: false,
    trash: false,
  },
  {
    id: 104,
    title: "Taking breakfast",
    createDate: "15.10.2023",
    done: true,
    trash: false,
  },
  {
    id: 105,
    title: "Meet batch advisor",
    createDate: "13.09.2023",
    done: true,
    trash: false,
  },
  {
    id: 106,
    title: "Community service",
    createDate: "29.10.2023",
    done: true,
    trash: false,
  },
];
