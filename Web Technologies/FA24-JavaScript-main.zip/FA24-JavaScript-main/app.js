// Write JavaScript code here...
// Modify and excute it to learn

// use terminal command $ node app.js
