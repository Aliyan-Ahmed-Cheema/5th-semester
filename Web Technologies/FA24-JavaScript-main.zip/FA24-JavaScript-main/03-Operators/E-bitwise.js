/**
==================================
 Operators
==================================
 Bitwise Operators
----------------------------------
 &	    AND	
 |	    OR	
 ~	    NOT	
 ^	    XOR	
 <<	    left shift
 >>	    right shift
 >>>	unsigned right shift
==================================
*/
