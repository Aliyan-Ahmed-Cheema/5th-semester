/**
==================================
 JavaScript in Browser
==================================
Requires:
* Text Editor or IDE
* JavaScript Runtime Environment
----------------------------------
* How to execute the JS program and basic requirements
  --> VS Code or any other IDE
  --> Node.js
==================================
*/

console.log("This is message in the console of the browser");
