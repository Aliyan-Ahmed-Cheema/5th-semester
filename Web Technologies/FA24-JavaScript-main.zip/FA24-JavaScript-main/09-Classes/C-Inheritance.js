/**
==================================
 Classes
==================================
  Inheritance
==================================
*/

console.log("==============================================");
// Class declaration
class Vehicle {
  // ....
}

class Car extends Vehicle {
  // ....
}

const newCar = new Car();
