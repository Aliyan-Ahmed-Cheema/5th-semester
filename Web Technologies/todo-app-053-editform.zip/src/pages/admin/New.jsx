import AddTask from "../../components/AddTask";

function New() {
  return <AddTask />;
}
export default New;
