﻿namespace Admin1
{
    partial class AdminFeedBack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminFeedBack));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Home = new System.Windows.Forms.Button();
            this.See_Feedback = new System.Windows.Forms.Button();
            this.See_Complaint = new System.Windows.Forms.Button();
            this.Add_Train = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.FeedbackGrid = new System.Windows.Forms.DataGridView();
            this.feedbackBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.railwayComplaintSystem15DataSet5 = new Admin1.RailwayComplaintSystem15DataSet5();
            this.feedbackBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.railwayComplaintSystem7DataSet10 = new Admin1.RailwayComplaintSystem7DataSet10();
            this.feedbackTableAdapter = new Admin1.RailwayComplaintSystem7DataSet10TableAdapters.feedbackTableAdapter();
            this.feedbackTableAdapter1 = new Admin1.RailwayComplaintSystem15DataSet5TableAdapters.feedbackTableAdapter();
            this.railwayComplaintSystem15DataSet6 = new Admin1.RailwayComplaintSystem15DataSet6();
            this.feedbackBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.feedbackTableAdapter2 = new Admin1.RailwayComplaintSystem15DataSet6TableAdapters.feedbackTableAdapter();
            this.feedbackIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.complaintIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passengersIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FeedbackGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.railwayComplaintSystem15DataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.railwayComplaintSystem7DataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.railwayComplaintSystem15DataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox3);
            this.bunifuGradientPanel1.Controls.Add(this.button1);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.panel3);
            this.bunifuGradientPanel1.Controls.Add(this.Home);
            this.bunifuGradientPanel1.Controls.Add(this.See_Feedback);
            this.bunifuGradientPanel1.Controls.Add(this.See_Complaint);
            this.bunifuGradientPanel1.Controls.Add(this.Add_Train);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Green;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(244, 619);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Admin1.Properties.Resources.download__4_;
            this.pictureBox3.Location = new System.Drawing.Point(12, 566);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(57, 53);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(67, 566);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(177, 53);
            this.button1.TabIndex = 0;
            this.button1.Text = "LOG OUT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(76, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "---Admin---";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Admin1.Properties.Resources.WhatsApp_Image_2022_12_19_at_01_53_58_removebg_preview;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(78, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Aqua;
            this.panel3.Location = new System.Drawing.Point(0, 438);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 55);
            this.panel3.TabIndex = 0;
            // 
            // Home
            // 
            this.Home.FlatAppearance.BorderSize = 0;
            this.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home.Location = new System.Drawing.Point(11, 197);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(247, 55);
            this.Home.TabIndex = 3;
            this.Home.Text = "HOME";
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // See_Feedback
            // 
            this.See_Feedback.FlatAppearance.BorderSize = 0;
            this.See_Feedback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.See_Feedback.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.See_Feedback.Location = new System.Drawing.Point(11, 439);
            this.See_Feedback.Name = "See_Feedback";
            this.See_Feedback.Size = new System.Drawing.Size(247, 55);
            this.See_Feedback.TabIndex = 2;
            this.See_Feedback.Text = "SEE FEEDBACKS";
            this.See_Feedback.UseVisualStyleBackColor = true;
            this.See_Feedback.Click += new System.EventHandler(this.See_Feedback_Click);
            // 
            // See_Complaint
            // 
            this.See_Complaint.FlatAppearance.BorderSize = 0;
            this.See_Complaint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.See_Complaint.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.See_Complaint.Location = new System.Drawing.Point(11, 357);
            this.See_Complaint.Name = "See_Complaint";
            this.See_Complaint.Size = new System.Drawing.Size(247, 55);
            this.See_Complaint.TabIndex = 1;
            this.See_Complaint.Text = "SEE COMPLAINTS";
            this.See_Complaint.UseVisualStyleBackColor = true;
            this.See_Complaint.Click += new System.EventHandler(this.See_Complaint_Click);
            // 
            // Add_Train
            // 
            this.Add_Train.FlatAppearance.BorderSize = 0;
            this.Add_Train.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Add_Train.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Train.Location = new System.Drawing.Point(11, 279);
            this.Add_Train.Name = "Add_Train";
            this.Add_Train.Size = new System.Drawing.Size(247, 55);
            this.Add_Train.TabIndex = 0;
            this.Add_Train.Text = "ADD TRAIN";
            this.Add_Train.UseVisualStyleBackColor = true;
            this.Add_Train.Click += new System.EventHandler(this.Add_Train_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel2.Controls.Add(this.FeedbackGrid);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.ForeColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(244, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(820, 619);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // FeedbackGrid
            // 
            this.FeedbackGrid.AutoGenerateColumns = false;
            this.FeedbackGrid.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.FeedbackGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FeedbackGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.feedbackIDDataGridViewTextBoxColumn,
            this.complaintIDDataGridViewTextBoxColumn,
            this.commentsDataGridViewTextBoxColumn,
            this.passengersIDDataGridViewTextBoxColumn});
            this.FeedbackGrid.DataSource = this.feedbackBindingSource2;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.FeedbackGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.FeedbackGrid.Location = new System.Drawing.Point(0, 0);
            this.FeedbackGrid.Name = "FeedbackGrid";
            this.FeedbackGrid.RowHeadersWidth = 51;
            this.FeedbackGrid.RowTemplate.Height = 24;
            this.FeedbackGrid.Size = new System.Drawing.Size(820, 619);
            this.FeedbackGrid.TabIndex = 20;
            this.FeedbackGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.FeedbackGrid_CellContentClick);
            // 
            // feedbackBindingSource1
            // 
            this.feedbackBindingSource1.DataMember = "feedback";
            this.feedbackBindingSource1.DataSource = this.railwayComplaintSystem15DataSet5;
            // 
            // railwayComplaintSystem15DataSet5
            // 
            this.railwayComplaintSystem15DataSet5.DataSetName = "RailwayComplaintSystem15DataSet5";
            this.railwayComplaintSystem15DataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feedbackBindingSource
            // 
            this.feedbackBindingSource.DataMember = "feedback";
            this.feedbackBindingSource.DataSource = this.railwayComplaintSystem7DataSet10;
            // 
            // railwayComplaintSystem7DataSet10
            // 
            this.railwayComplaintSystem7DataSet10.DataSetName = "RailwayComplaintSystem7DataSet10";
            this.railwayComplaintSystem7DataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feedbackTableAdapter
            // 
            this.feedbackTableAdapter.ClearBeforeFill = true;
            // 
            // feedbackTableAdapter1
            // 
            this.feedbackTableAdapter1.ClearBeforeFill = true;
            // 
            // railwayComplaintSystem15DataSet6
            // 
            this.railwayComplaintSystem15DataSet6.DataSetName = "RailwayComplaintSystem15DataSet6";
            this.railwayComplaintSystem15DataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feedbackBindingSource2
            // 
            this.feedbackBindingSource2.DataMember = "feedback";
            this.feedbackBindingSource2.DataSource = this.railwayComplaintSystem15DataSet6;
            // 
            // feedbackTableAdapter2
            // 
            this.feedbackTableAdapter2.ClearBeforeFill = true;
            // 
            // feedbackIDDataGridViewTextBoxColumn
            // 
            this.feedbackIDDataGridViewTextBoxColumn.DataPropertyName = "feedbackID";
            this.feedbackIDDataGridViewTextBoxColumn.HeaderText = "feedbackID";
            this.feedbackIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.feedbackIDDataGridViewTextBoxColumn.Name = "feedbackIDDataGridViewTextBoxColumn";
            this.feedbackIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.feedbackIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // complaintIDDataGridViewTextBoxColumn
            // 
            this.complaintIDDataGridViewTextBoxColumn.DataPropertyName = "complaintID";
            this.complaintIDDataGridViewTextBoxColumn.HeaderText = "complaintID";
            this.complaintIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.complaintIDDataGridViewTextBoxColumn.Name = "complaintIDDataGridViewTextBoxColumn";
            this.complaintIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // commentsDataGridViewTextBoxColumn
            // 
            this.commentsDataGridViewTextBoxColumn.DataPropertyName = "comments";
            this.commentsDataGridViewTextBoxColumn.HeaderText = "comments";
            this.commentsDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.commentsDataGridViewTextBoxColumn.Name = "commentsDataGridViewTextBoxColumn";
            this.commentsDataGridViewTextBoxColumn.Width = 325;
            // 
            // passengersIDDataGridViewTextBoxColumn
            // 
            this.passengersIDDataGridViewTextBoxColumn.DataPropertyName = "PassengersID";
            this.passengersIDDataGridViewTextBoxColumn.HeaderText = "PassengersID";
            this.passengersIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passengersIDDataGridViewTextBoxColumn.Name = "passengersIDDataGridViewTextBoxColumn";
            this.passengersIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // AdminFeedBack
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1064, 619);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminFeedBack";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.AdminFeedBack_Load);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.FeedbackGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.railwayComplaintSystem15DataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.railwayComplaintSystem7DataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.railwayComplaintSystem15DataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button See_Feedback;
        private System.Windows.Forms.Button See_Complaint;
        private System.Windows.Forms.Button Add_Train;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private RailwayComplaintSystem7DataSet10 railwayComplaintSystem7DataSet10;
        private System.Windows.Forms.BindingSource feedbackBindingSource;
        private RailwayComplaintSystem7DataSet10TableAdapters.feedbackTableAdapter feedbackTableAdapter;
        private System.Windows.Forms.DataGridView FeedbackGrid;
        private RailwayComplaintSystem15DataSet5 railwayComplaintSystem15DataSet5;
        private System.Windows.Forms.BindingSource feedbackBindingSource1;
        private RailwayComplaintSystem15DataSet5TableAdapters.feedbackTableAdapter feedbackTableAdapter1;
        private RailwayComplaintSystem15DataSet6 railwayComplaintSystem15DataSet6;
        private System.Windows.Forms.BindingSource feedbackBindingSource2;
        private RailwayComplaintSystem15DataSet6TableAdapters.feedbackTableAdapter feedbackTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn feedbackIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn complaintIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passengersIDDataGridViewTextBoxColumn;
    }
}