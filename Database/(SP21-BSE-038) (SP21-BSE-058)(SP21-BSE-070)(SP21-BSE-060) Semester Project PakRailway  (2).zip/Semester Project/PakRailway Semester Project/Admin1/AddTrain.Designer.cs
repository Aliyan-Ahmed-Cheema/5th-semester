﻿namespace Admin1
{
    partial class AddTrain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddTrain));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.TrainID = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Depaturetime3 = new System.Windows.Forms.TextBox();
            this.Stop3 = new System.Windows.Forms.TextBox();
            this.Departuretime2 = new System.Windows.Forms.TextBox();
            this.Stop2 = new System.Windows.Forms.TextBox();
            this.Departuretime1 = new System.Windows.Forms.TextBox();
            this.Stop1 = new System.Windows.Forms.TextBox();
            this.Endpoint = new System.Windows.Forms.TextBox();
            this.StartingPoint = new System.Windows.Forms.TextBox();
            this.NumberOfcabin = new System.Windows.Forms.TextBox();
            this.NumberOfseat = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bunifuGradientPanel1 = new Bunifu.UI.WinForms.BunifuGradientPanel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Home = new System.Windows.Forms.Button();
            this.See_Feedback = new System.Windows.Forms.Button();
            this.See_Complaint = new System.Windows.Forms.Button();
            this.Add_Train = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.TrainID);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.Depaturetime3);
            this.panel2.Controls.Add(this.Stop3);
            this.panel2.Controls.Add(this.Departuretime2);
            this.panel2.Controls.Add(this.Stop2);
            this.panel2.Controls.Add(this.Departuretime1);
            this.panel2.Controls.Add(this.Stop1);
            this.panel2.Controls.Add(this.Endpoint);
            this.panel2.Controls.Add(this.StartingPoint);
            this.panel2.Controls.Add(this.NumberOfcabin);
            this.panel2.Controls.Add(this.NumberOfseat);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(244, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(820, 619);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(60, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 25);
            this.label2.TabIndex = 17;
            this.label2.Text = "TrainID";
            // 
            // TrainID
            // 
            this.TrainID.BackColor = System.Drawing.Color.Silver;
            this.TrainID.Location = new System.Drawing.Point(231, 51);
            this.TrainID.Multiline = true;
            this.TrainID.Name = "TrainID";
            this.TrainID.Size = new System.Drawing.Size(154, 34);
            this.TrainID.TabIndex = 16;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.Font = new System.Drawing.Font("Nirmala UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(280, 451);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(258, 68);
            this.button1.TabIndex = 15;
            this.button1.Text = "SUBMIT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Depaturetime3
            // 
            this.Depaturetime3.BackColor = System.Drawing.Color.Silver;
            this.Depaturetime3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Depaturetime3.Location = new System.Drawing.Point(635, 317);
            this.Depaturetime3.Multiline = true;
            this.Depaturetime3.Name = "Depaturetime3";
            this.Depaturetime3.Size = new System.Drawing.Size(154, 35);
            this.Depaturetime3.TabIndex = 14;
            // 
            // Stop3
            // 
            this.Stop3.BackColor = System.Drawing.Color.Silver;
            this.Stop3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Stop3.Location = new System.Drawing.Point(231, 388);
            this.Stop3.Multiline = true;
            this.Stop3.Name = "Stop3";
            this.Stop3.Size = new System.Drawing.Size(154, 38);
            this.Stop3.TabIndex = 14;
            // 
            // Departuretime2
            // 
            this.Departuretime2.BackColor = System.Drawing.Color.Silver;
            this.Departuretime2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Departuretime2.Location = new System.Drawing.Point(635, 255);
            this.Departuretime2.Multiline = true;
            this.Departuretime2.Name = "Departuretime2";
            this.Departuretime2.Size = new System.Drawing.Size(154, 35);
            this.Departuretime2.TabIndex = 14;
            // 
            // Stop2
            // 
            this.Stop2.BackColor = System.Drawing.Color.Silver;
            this.Stop2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Stop2.Location = new System.Drawing.Point(231, 329);
            this.Stop2.Multiline = true;
            this.Stop2.Name = "Stop2";
            this.Stop2.Size = new System.Drawing.Size(154, 38);
            this.Stop2.TabIndex = 14;
            // 
            // Departuretime1
            // 
            this.Departuretime1.BackColor = System.Drawing.Color.Silver;
            this.Departuretime1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Departuretime1.Location = new System.Drawing.Point(635, 191);
            this.Departuretime1.Multiline = true;
            this.Departuretime1.Name = "Departuretime1";
            this.Departuretime1.Size = new System.Drawing.Size(154, 35);
            this.Departuretime1.TabIndex = 14;
            this.Departuretime1.TextChanged += new System.EventHandler(this.Departuretime1_TextChanged);
            // 
            // Stop1
            // 
            this.Stop1.BackColor = System.Drawing.Color.Silver;
            this.Stop1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Stop1.Location = new System.Drawing.Point(231, 262);
            this.Stop1.Multiline = true;
            this.Stop1.Name = "Stop1";
            this.Stop1.Size = new System.Drawing.Size(154, 38);
            this.Stop1.TabIndex = 14;
            this.Stop1.TextChanged += new System.EventHandler(this.Stop1_TextChanged);
            // 
            // Endpoint
            // 
            this.Endpoint.BackColor = System.Drawing.Color.Silver;
            this.Endpoint.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Endpoint.Location = new System.Drawing.Point(635, 125);
            this.Endpoint.Multiline = true;
            this.Endpoint.Name = "Endpoint";
            this.Endpoint.Size = new System.Drawing.Size(154, 35);
            this.Endpoint.TabIndex = 14;
            // 
            // StartingPoint
            // 
            this.StartingPoint.BackColor = System.Drawing.Color.Silver;
            this.StartingPoint.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.StartingPoint.Location = new System.Drawing.Point(231, 195);
            this.StartingPoint.Multiline = true;
            this.StartingPoint.Name = "StartingPoint";
            this.StartingPoint.Size = new System.Drawing.Size(154, 38);
            this.StartingPoint.TabIndex = 14;
            // 
            // NumberOfcabin
            // 
            this.NumberOfcabin.BackColor = System.Drawing.Color.Silver;
            this.NumberOfcabin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NumberOfcabin.Location = new System.Drawing.Point(231, 125);
            this.NumberOfcabin.Multiline = true;
            this.NumberOfcabin.Name = "NumberOfcabin";
            this.NumberOfcabin.Size = new System.Drawing.Size(154, 38);
            this.NumberOfcabin.TabIndex = 14;
            // 
            // NumberOfseat
            // 
            this.NumberOfseat.BackColor = System.Drawing.Color.Silver;
            this.NumberOfseat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NumberOfseat.Location = new System.Drawing.Point(635, 50);
            this.NumberOfseat.Multiline = true;
            this.NumberOfseat.Name = "NumberOfseat";
            this.NumberOfseat.Size = new System.Drawing.Size(154, 35);
            this.NumberOfseat.TabIndex = 14;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label13.Location = new System.Drawing.Point(433, 118);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 25);
            this.label13.TabIndex = 11;
            this.label13.Text = "Ending Point";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label12.Location = new System.Drawing.Point(67, 326);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 25);
            this.label12.TabIndex = 10;
            this.label12.Text = "Stop 2";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label11.Location = new System.Drawing.Point(433, 248);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(163, 25);
            this.label11.TabIndex = 9;
            this.label11.Text = "Departure Time 2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label10.Location = new System.Drawing.Point(56, 121);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(169, 25);
            this.label10.TabIndex = 8;
            this.label10.Text = "Number of Cabins";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(67, 192);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(133, 25);
            this.label9.TabIndex = 7;
            this.label9.Text = "Starting Point ";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.Location = new System.Drawing.Point(430, 327);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(163, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "Departure Time 3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(67, 384);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 25);
            this.label7.TabIndex = 5;
            this.label7.Text = "Stop 3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label6.Location = new System.Drawing.Point(433, 184);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Departure time 1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(67, 262);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 25);
            this.label5.TabIndex = 3;
            this.label5.Text = "Stop 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(430, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(158, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Number of Seats";
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.BorderRadius = 1;
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox3);
            this.bunifuGradientPanel1.Controls.Add(this.button2);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.panel3);
            this.bunifuGradientPanel1.Controls.Add(this.Home);
            this.bunifuGradientPanel1.Controls.Add(this.See_Feedback);
            this.bunifuGradientPanel1.Controls.Add(this.See_Complaint);
            this.bunifuGradientPanel1.Controls.Add(this.Add_Train);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Green;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(244, 619);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Admin1.Properties.Resources.download__4_;
            this.pictureBox3.Location = new System.Drawing.Point(12, 566);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(57, 53);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(67, 566);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 53);
            this.button2.TabIndex = 5;
            this.button2.Text = "LOG OUT";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(76, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "---ADMIN---";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::Admin1.Properties.Resources.WhatsApp_Image_2022_12_19_at_01_53_58_removebg_preview;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(90, 47);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Aqua;
            this.panel3.Location = new System.Drawing.Point(0, 280);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(10, 55);
            this.panel3.TabIndex = 0;
            // 
            // Home
            // 
            this.Home.FlatAppearance.BorderSize = 0;
            this.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home.Location = new System.Drawing.Point(11, 197);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(247, 55);
            this.Home.TabIndex = 3;
            this.Home.Text = "HOME";
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // See_Feedback
            // 
            this.See_Feedback.FlatAppearance.BorderColor = System.Drawing.SystemColors.ActiveBorder;
            this.See_Feedback.FlatAppearance.BorderSize = 0;
            this.See_Feedback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.See_Feedback.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.See_Feedback.Location = new System.Drawing.Point(11, 439);
            this.See_Feedback.Name = "See_Feedback";
            this.See_Feedback.Size = new System.Drawing.Size(247, 55);
            this.See_Feedback.TabIndex = 2;
            this.See_Feedback.Text = "SEE FEEDBACKS";
            this.See_Feedback.UseVisualStyleBackColor = true;
            this.See_Feedback.Click += new System.EventHandler(this.See_Feedback_Click);
            // 
            // See_Complaint
            // 
            this.See_Complaint.FlatAppearance.BorderSize = 0;
            this.See_Complaint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.See_Complaint.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.See_Complaint.Location = new System.Drawing.Point(11, 357);
            this.See_Complaint.Name = "See_Complaint";
            this.See_Complaint.Size = new System.Drawing.Size(247, 55);
            this.See_Complaint.TabIndex = 1;
            this.See_Complaint.Text = "SEE COMPLAINTS";
            this.See_Complaint.UseVisualStyleBackColor = true;
            this.See_Complaint.Click += new System.EventHandler(this.See_Complaint_Click);
            // 
            // Add_Train
            // 
            this.Add_Train.FlatAppearance.BorderSize = 0;
            this.Add_Train.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Add_Train.Font = new System.Drawing.Font("Nirmala UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add_Train.Location = new System.Drawing.Point(11, 279);
            this.Add_Train.Name = "Add_Train";
            this.Add_Train.Size = new System.Drawing.Size(247, 55);
            this.Add_Train.TabIndex = 0;
            this.Add_Train.Text = "ADD TRAIN";
            this.Add_Train.UseVisualStyleBackColor = true;
            this.Add_Train.Click += new System.EventHandler(this.Add_Train_Click);
            // 
            // AddTrain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.ClientSize = new System.Drawing.Size(1064, 619);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddTrain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private Bunifu.UI.WinForms.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button See_Feedback;
        private System.Windows.Forms.Button See_Complaint;
        private System.Windows.Forms.Button Add_Train;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox NumberOfseat;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox Depaturetime3;
        private System.Windows.Forms.TextBox Stop3;
        private System.Windows.Forms.TextBox Departuretime2;
        private System.Windows.Forms.TextBox Stop2;
        private System.Windows.Forms.TextBox Departuretime1;
        private System.Windows.Forms.TextBox Stop1;
        private System.Windows.Forms.TextBox Endpoint;
        private System.Windows.Forms.TextBox StartingPoint;
        private System.Windows.Forms.TextBox NumberOfcabin;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TrainID;
    }
}