import { Loader2 } from "lucide-react";

const Loader = () => {
  return <Loader2 size={40} className="spin-animation" />;
};

export default Loader;
