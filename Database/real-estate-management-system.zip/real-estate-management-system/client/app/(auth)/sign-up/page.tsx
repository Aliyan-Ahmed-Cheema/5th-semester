import AuthForm from "@/components/Forms/AuthForm";

const SignUp = () => {
  return (
    <div>
      <AuthForm type="sign-up" />
    </div>
  );
};

export default SignUp;
