import AuthForm from "@/components/Forms/AuthForm";

const Login = () => {
  return (
    <div>
      <AuthForm type="login" />
    </div>
  );
};

export default Login;
