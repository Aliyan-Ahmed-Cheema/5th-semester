-- AlterTable
ALTER TABLE "Listing" ADD COLUMN     "interestedClients" TEXT[];
